This issue tracker is not for end users!
Don't create any new issues as they will immediately be closed as invalid.
Questions and discussions are at: https://github.com/zmartzone/mod_auth_openidc/discussions
There's also a user mailing list at: mod_auth_openidc@googlegroups.com
